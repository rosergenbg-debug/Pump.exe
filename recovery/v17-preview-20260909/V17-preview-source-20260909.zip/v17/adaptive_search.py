"""Adaptive TPE proposals and patient trial pruning. Single coordinator only.

No market replay, holdout access or convergence claim lives in this component.
"""
import hashlib
import math
import optuna
from run_control import canonical


def effective_parameters(parameters):
    """Bound pairs are encoded by two endpoints and evaluated in sorted order.

    Optuna keeps original endpoints in trial.params; the effective values and hash
    are saved separately. This is an explicit parameterization, not silent pruning.
    """
    result = dict(parameters)
    for key in tuple(result):
        if key.startswith("min_"):
            upper = "max_" + key[4:]
            if upper in result and result[key] > result[upper]:
                result[key], result[upper] = result[upper], result[key]
    return result


class AdaptiveSearch:
    def __init__(self, domains, context, storage=None, seed=17):
        if optuna.__version__ != "4.5.0":
            raise RuntimeError("Use pinned Optuna 4.5.0 for this checkpoint")
        if not domains or any(not values for values in domains.values()):
            raise ValueError("Nonempty domains required")
        self.domains = {k: list(v) for k, v in sorted(domains.items())}
        self.seed = seed
        self.rdb = optuna.storages.RDBStorage(storage) if isinstance(storage, str) else None
        self.study = optuna.create_study(
            study_name=str(context["run_id"]), storage=self.rdb if self.rdb is not None else storage, load_if_exists=True,
            direction="maximize",
            pruner=optuna.pruners.PatientPruner(
                optuna.pruners.MedianPruner(n_startup_trials=20, n_warmup_steps=3, n_min_trials=10),
                patience=2))
        identity = canonical({"domains": self.domains, "context": context, "seed": seed,
                              "sampler": "TPE-4.5.0", "objective": "NET_after_costs", "parameterization":"ordered-bound-pairs-v1"})
        old = self.study.user_attrs.get("identity")
        if old is not None and old != identity:
            raise ValueError("Adaptive study identity mismatch")
        if old is None:
            self.study.set_user_attr("identity", identity)
        self.seen = {trial.user_attrs["candidate_hash"] for trial in self.study.trials
                     if "candidate_hash" in trial.user_attrs}

    def ask(self, attempts=64):
        """Returns no candidate on proposal saturation, NOT a convergence result.

        Attempt bound limits duplicate generation per call, never total research.
        Re-seeding per persisted trial number avoids unsafe pickle checkpoints.
        Ordered completed history is still required for deterministic proposals.
        """
        total = math.prod(len({canonical(v) for v in values}) for values in self.domains.values())
        if len(self.seen) >= total:
            return None
        for _ in range(attempts):
            number = len(self.study.trials)
            seed = (self.seed + number) % (2**32)
            exploration = number % 5 == 0
            self.study.sampler = (optuna.samplers.RandomSampler(seed=seed) if exploration else
                optuna.samplers.TPESampler(seed=seed, multivariate=True, group=True,
                                           constant_liar=True, n_startup_trials=20))
            trial = self.study.ask()
            parameters = {name: trial.suggest_categorical(name, values)
                          for name, values in self.domains.items()}
            parameters = effective_parameters(parameters)
            digest = hashlib.sha256(canonical(parameters).encode()).hexdigest()
            if digest in self.seen:
                trial.set_user_attr("reason", "duplicate_proposal_not_evaluated")
                self.study.tell(trial, state=optuna.trial.TrialState.FAIL)
                continue
            self.seen.add(digest)
            trial.set_user_attr("candidate_hash", digest)
            trial.set_user_attr("effective_parameters", parameters)
            trial.set_user_attr("proposal_kind", "exploration" if exploration else "TPE")
            return trial, parameters
        return None

    def report(self, trial, step, net):
        if step < 0 or not math.isfinite(net):
            raise ValueError("Finite comparable development score required")
        trial.report(net, step)
        return trial.should_prune()

    def finish(self, trial, net):
        if not math.isfinite(net):
            raise ValueError("Completed NET must be finite")
        self.study.tell(trial, net)

    def prune(self, trial, reason):
        if not reason:
            raise ValueError("Pruning reason required")
        trial.set_user_attr("prune_reason", reason)
        self.study.tell(trial, state=optuna.trial.TrialState.PRUNED)

    def close(self):
        if self.rdb is not None:
            self.rdb.remove_session()
            self.rdb.engine.dispose()
