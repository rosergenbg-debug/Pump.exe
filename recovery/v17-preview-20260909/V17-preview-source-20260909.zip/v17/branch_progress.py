"""Heuristic local stagnation detection, never proof of a global optimum."""
from dataclasses import dataclass, field
import hashlib
import math
from run_control import canonical


def behavior_fingerprint(context, trades, equity_curve, final_state):
    """Same NET alone must never collapse distinct risk or execution paths.

    Inputs must be complete, unrounded execution/accounting records on the same
    development data. This signature is not a claim of equivalence on future data.
    """
    return hashlib.sha256(canonical(dict(context=context, trades=trades,
        equity_curve=equity_curve, final_state=final_state)).encode()).hexdigest()


@dataclass
class BranchProgress:
    # Explicit search-policy defaults, not trading limits or profit ceilings.
    meaningful_net_delta: float = 0.001
    patience: int = 3
    best_net: float | None = None
    stagnant_rounds: int = 0
    state: str = "ACTIVE"
    seen_behaviors: set = field(default_factory=set)

    def __post_init__(self):
        if not math.isfinite(self.meaningful_net_delta) or self.meaningful_net_delta < 0 or self.patience < 1:
            raise ValueError("Invalid plateau policy")

    def finish_round(self, results, *, comparable_complete, directions_covered):
        """One completed local-neighbourhood round, not one individual trial.

        Only a coordinator with frozen context may set comparable_complete.
        Results with tiny real improvements stay archived even if this branch rests.
        """
        if not comparable_complete or not directions_covered:
            return "INSUFFICIENT_EVIDENCE"
        if not results:
            return "NO_RESULTS"
        values = [net for _, net in results]
        if any(not math.isfinite(net) for net in values):
            raise ValueError("Invalid completed NET")
        novel = [(key, net) for key, net in results if key not in self.seen_behaviors]
        self.seen_behaviors.update(key for key, _ in results)
        previous = self.best_net
        round_best = max(values)
        self.best_net = round_best if previous is None else max(previous, round_best)
        improvement = previous is None or (bool(novel) and max(net for _, net in novel) > previous + self.meaningful_net_delta)
        self.stagnant_rounds = 0 if improvement else self.stagnant_rounds + 1
        self.state = "RESTING" if self.stagnant_rounds >= self.patience else "ACTIVE"
        return self.state

    def reopen(self, reason):
        if reason not in ("new_joint_parameter_direction", "new_data_new_campaign"):
            raise ValueError("Reopening requires a genuinely new hypothesis")
        self.stagnant_rounds = 0
        self.state = "ACTIVE"
