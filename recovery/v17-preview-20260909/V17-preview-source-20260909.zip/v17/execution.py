"""Process-isolated replay and cooperative pause for V17 campaigns."""
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import multiprocessing
import threading
from campaign import Campaign, atomic_json
from engine_bridge import EngineBridge, load_engine

_bridge = None


def load_rows(paths):
    load_engine()
    from pump_research_lab.domain import Candle
    output = []
    for path in paths:
        values = {}
        with Path(path).open(encoding="utf-8") as handle:
            for line in handle:
                candle = Candle.from_dict(json.loads(line))
                if candle.open_time_ms in values:
                    raise ValueError("Duplicate timestamp in input")
                values[candle.open_time_ms] = candle
        output.append([values[key] for key in sorted(values)])
    return output


def init_worker(paths):
    global _bridge
    _bridge = EngineBridge(*load_rows(paths))


def evaluate(parameters, context):
    result = _bridge.replay(parameters)
    value = result.to_dict()
    curve = [[timestamp, equity*1000] for timestamp, equity in result.equity_curve]
    return dict(context=context, parameters=parameters, net=value["metrics"]["compound_net"],
        trades=value["trades"], metrics=value["metrics"], equity_curve=curve,
        final_state={"capital":1000*(1+value["metrics"]["compound_net"])},
        period=value["period"], execution_config=value["config"],
        status="DONE", label="DEVELOPMENT_ONLY_NOT_INDEPENDENT_TEST")


def dataset_identity(paths):
    hashes = []
    for path in paths:
        h = hashlib.sha256()
        with Path(path).open("rb") as handle:
            for block in iter(lambda:handle.read(1024*1024), b""):
                h.update(block)
        hashes.append(h.hexdigest())
    return hashlib.sha256("|".join(hashes).encode()).hexdigest()


class CampaignRunner:
    def __init__(self, directory, paths, domains, context, workers=2):
        self.directory = Path(directory)
        self.paths = list(map(str, paths))
        self.domains = domains
        self.context = context
        self.workers = workers
        self.pause_requested = threading.Event()

    def run(self, emit=lambda value:None):
        campaign = Campaign(self.directory, self.domains, self.context)
        try:
            # Reconcile the immutable result before dispatch; finished work is not rerun.
            for item in campaign.state["round_trials"]:
                path = self.directory / f"candidate-{item['number']:09d}.json"
                if item["state"] != "DONE" and path.exists():
                    campaign.record(item, json.loads(path.read_text(encoding="utf-8")))
            if campaign.state["phase"] == "COMPLETED":
                emit(dict(phase="COMPLETED", best=campaign.best(), completed=len(campaign.state["results"])))
                return
            emit(dict(phase="PREPARING_FEATURES", workers=self.workers))
            with ProcessPoolExecutor(max_workers=self.workers,
                    mp_context=multiprocessing.get_context("spawn"),
                    initializer=init_worker, initargs=(self.paths,)) as pool:
                while not self.pause_requested.is_set():
                    items = campaign.propose_round()
                    if not items:
                        break
                    pending = iter(item for item in items if item["state"] != "DONE")
                    active = {}
                    exhausted = False
                    while active or not exhausted:
                        while not exhausted and len(active) < self.workers and not self.pause_requested.is_set():
                            item = next(pending, None)
                            if item is None:
                                exhausted = True
                                break
                            active[pool.submit(evaluate, item["parameters"], self.context)] = item
                        if not active:
                            break
                        completed, _ = wait(active, timeout=.5, return_when=FIRST_COMPLETED)
                        for future in completed:
                            item = active.pop(future)
                            campaign.record(item, future.result())
                            best = campaign.best()
                            summary = dict(phase="DRAINING_FOR_PAUSE" if self.pause_requested.is_set() else "RUNNING",
                                round=campaign.state["round"]+1, round_size=len(items),
                                completed=len(campaign.state["results"]), running=len(active), best=best)
                            atomic_json(self.directory / "LIVE_V17.json", summary)
                            emit(summary)
                        if self.pause_requested.is_set() and not active:
                            break
                    if self.pause_requested.is_set():
                        campaign.state["phase"] = "PAUSED"
                        campaign.save()
                        break
                    if campaign.finish_round() == "COMPLETED":
                        break
            summary = dict(phase=campaign.state["phase"], completed=len(campaign.state["results"]),
                           best=campaign.best(), stop_reason=campaign.state["stop_reason"])
            atomic_json(self.directory / "LIVE_V17.json", summary)
            emit(summary)
        finally:
            campaign.close()
