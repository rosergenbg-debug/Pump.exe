from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest
from engine_bridge import load_engine
from execution import CampaignRunner, dataset_identity


class ExecutionTests(unittest.TestCase):
    def test_real_spawn_replay_checkpoint_and_no_recalculation(self):
        load_engine()
        from pump_research_lab.demo import demo_candles
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            paths = []
            for symbol in ("PUMPUSDT", "BTCUSDT", "SOLUSDT"):
                path = root / (symbol+".jsonl")
                with path.open("w", encoding="utf-8") as handle:
                    for row in demo_candles():
                        handle.write(json.dumps(replace(row,symbol=symbol).to_dict())+"\n")
                paths.append(path)
            context = dict(run_id="spawn-fixture", version="V17", dataset_sha256=dataset_identity(paths),
                           engine="V16-frozen", evaluation="development")
            runner = CampaignRunner(root/"experiment", paths, {"target_net":[.025]}, context, workers=1)
            messages = []
            runner.run(messages.append)
            self.assertEqual(messages[-1]["completed"], 1)
            self.assertAlmostEqual(messages[-1]["best"]["net"], .025)
            runner.run(messages.append)
            self.assertEqual(messages[-1]["completed"], 1)
            self.assertEqual(len(list((root/"experiment").glob("candidate-*.json"))), 1)

            paused = CampaignRunner(root/"paused", paths, {"target_net":[.025,.03]},
                dict(context,run_id="pause-fixture"),workers=1)
            paused_messages = []
            def stop_after_first(message):
                paused_messages.append(message)
                if message.get("completed",0) >= 1:
                    paused.pause_requested.set()
            paused.run(stop_after_first)
            self.assertEqual(paused_messages[-1]["phase"], "PAUSED")
            saved = list((root/"paused").glob("candidate-*.json"))[0]
            before = saved.read_bytes()
            resumed = CampaignRunner(root/"paused", paths, {"target_net":[.025,.03]},
                dict(context,run_id="pause-fixture"),workers=1)
            resumed.run(paused_messages.append)
            self.assertEqual(paused_messages[-1]["completed"], 2)
            self.assertEqual(saved.read_bytes(),before)
