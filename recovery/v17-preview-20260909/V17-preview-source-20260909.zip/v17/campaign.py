"""Durable adaptive campaign orchestration; no GUI or global-space enumeration.

Coordinator-only state. Engine evaluation is injected for deterministic testing.
Candidate-level early pruning is not enabled until incremental replay is verified.
"""
from dataclasses import asdict
from pathlib import Path
import json
import hashlib
import math
import optuna
from adaptive_search import AdaptiveSearch
from branch_progress import BranchProgress, behavior_fingerprint
from run_control import canonical


def atomic_json(path, value):
    path = Path(path)
    partial = path.with_suffix(path.suffix + ".partial")
    with partial.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.flush()
        import os
        os.fsync(handle.fileno())
    partial.replace(path)


class Campaign:
    def __init__(self, root, domains, context, seed=17):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.context = json.loads(canonical(context))
        identity = canonical(dict(context=context, domains=domains, seed=seed))
        meta = self.root / "campaign.json"
        if meta.exists():
            state = json.loads(meta.read_text(encoding="utf-8"))
            if state["identity"] != identity:
                raise ValueError("Cannot resume on different data or parameters")
        else:
            state = dict(identity=identity, phase="READY", round=0, round_trials=[],
                         branches={}, results={}, error_count=0, stop_reason=None,
                         independent_restart=False)
            atomic_json(meta, state)
        self.state = state
        self.meta = meta
        self.search = AdaptiveSearch(domains, context,
            storage="sqlite:///" + (self.root / "study.sqlite3").as_posix(), seed=seed)
        self.round_size = max(20, len(domains)*2)

    def save(self):
        atomic_json(self.meta, self.state)

    def close(self):
        self.search.close()

    def propose_round(self):
        if self.state["phase"] == "COMPLETED":
            return []
        if self.state["round_trials"]:
            return self.state["round_trials"]
        proposed = []
        for _ in range(self.round_size):
            pair = self.search.ask()
            if pair is None:
                break
            trial, parameters = pair
            proposed.append(dict(trial_id=trial._trial_id, number=trial.number,
                                 parameters=parameters, state="PENDING"))
            # Persist each reservation, not just a large round boundary.
            self.state["round_trials"] = proposed
            self.state["phase"] = "RUNNING"
            self.save()
        if not proposed:
            self.state["phase"] = "PROPOSAL_SATURATION"
            self.state["stop_reason"] = "Sampler found no new proposal; not proof of convergence"
            self.save()
        return proposed

    def record(self, item, result):
        """Store an immutable result before acknowledging it to the sampler."""
        if result.get("context") != self.context or result.get("parameters") != item["parameters"]:
            raise ValueError("Evaluator identity mismatch")
        if not math.isfinite(result["net"]):
            raise ValueError("Non-finite result")
        number = item["number"]
        path = self.root / f"candidate-{number:09d}.json"
        if path.exists():
            if canonical(json.loads(path.read_text(encoding="utf-8"))) != canonical(result):
                raise ValueError("Refusing to replace an existing result")
        else:
            atomic_json(path, result)
        trial = optuna.trial.Trial(self.search.study, item["trial_id"])
        frozen = self.search.study.trials[number]
        if frozen.state == optuna.trial.TrialState.RUNNING:
            self.search.finish(trial, result["net"])
        elif frozen.state != optuna.trial.TrialState.COMPLETE or frozen.value != result["net"]:
            raise ValueError("Sampler and archive disagree")
        item["state"] = "DONE"
        item["net"] = result["net"]
        item["behavior"] = behavior_fingerprint(self.context, result["trades"],
                                                result["equity_curve"], result["final_state"])
        item["path"] = str(path)
        self.state["results"][str(number)] = dict(net=result["net"], path=str(path),
            family=item["parameters"].get("entry_family", "DEFAULT"), behavior=item["behavior"])
        self.save()

    def best(self):
        values = self.state["results"].values()
        best = max(values, key=lambda r:r["net"], default=None)
        return json.loads(Path(best["path"]).read_text(encoding="utf-8")) if best else None

    def finish_round(self):
        items = self.state["round_trials"]
        if not items or any(item["state"] != "DONE" for item in items):
            raise ValueError("Only fully resolved successful rounds can establish stagnation")
        families = self.search.domains.get("entry_family", ["DEFAULT"])
        covered = True
        for family in families:
            evidence = [(i["behavior"], i["net"]) for i in items if i["parameters"].get("entry_family", "DEFAULT") == family]
            if not evidence:
                covered = False
                continue
            saved = self.state["branches"].get(str(family), {})
            if saved:
                saved = dict(saved, seen_behaviors=set(saved["seen_behaviors"]))
            branch = BranchProgress(**saved)
            # Family-level proposal rounds; local geometric coverage is not claimed.
            branch.finish_round(evidence, comparable_complete=True, directions_covered=True)
            serialized = asdict(branch)
            serialized["seen_behaviors"] = sorted(serialized["seen_behaviors"])
            self.state["branches"][str(family)] = serialized
        resting = covered and all(self.state["branches"][str(f)]["state"] == "RESTING" for f in families)
        self.state["round"] += 1
        self.state["round_trials"] = []
        if resting and not self.state["independent_restart"]:
            self.state["independent_restart"] = True
            for branch in self.state["branches"].values():
                branch["stagnant_rounds"] = 0
                branch["state"] = "ACTIVE"
            # This starts a fresh exploration phase, not statistical independence.
            self.state["phase"] = "EXPLORATION_RECHECK"
        elif resting:
            self.state["phase"] = "COMPLETED"
            self.state["stop_reason"] = "Heuristic stagnation across families after exploration recheck; not exhaustive or global optimum"
        else:
            self.state["phase"] = "RUNNING"
        self.save()
        return self.state["phase"]
