"""Read-only archive adapter; older overlapping windows remain separate rows."""
from datetime import datetime, timezone
from pathlib import Path
import json
import sqlite3
import zlib


def read_archive(new_root, old_root=Path(r"F:\PUMP Research Lab\experiments")):
    rows = []
    for path in sorted(Path(new_root).glob("*/candidate-*.json")):
        value = json.loads(path.read_text(encoding="utf-8"))
        rows.append(dict(id=path.parent.name+"/"+path.stem, version="V17", net=value["net"],
            trades=value["metrics"]["fills"], windows=1, status="DEVELOPMENT · полный выбранный период",
            date=datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat(), parameters=value["parameters"]))
    for path in sorted(Path(old_root).glob("v*/research.sqlite3")):
        if not path.parent.name.split("-")[0][1:].isdigit():
            continue
        connection = sqlite3.connect(path.as_uri()+"?mode=ro",uri=True,timeout=2)
        try:
            tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "trials" not in tables:
                continue
            for identifier, blob in connection.execute("SELECT id,result FROM trials WHERE result IS NOT NULL"):
                value = json.loads(zlib.decompress(blob) if isinstance(blob, bytes) else blob)
                version = path.parent.name.split("-")[0].upper()
                for regime, report in value.get("regimes",{}).items():
                    metrics = report.get("metrics",{})
                    if "compound_net" not in metrics:
                        continue
                    rows.append(dict(id=identifier+"/"+regime,version=version,net=metrics["compound_net"],
                        trades=metrics["fills"],windows=1,status=f"Архив · {regime} · окна могут пересекаться",
                        date=datetime.fromtimestamp(float(value.get("completed_at") or 0),timezone.utc).isoformat(),parameters=value.get("config",{})))
        finally:
            connection.close()
    return rows
