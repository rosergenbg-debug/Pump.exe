"""V17 development desktop. Data and engine validation before research integration."""
from pathlib import Path
import json
import os
import sys
import uuid
from PySide6.QtCore import Qt, Signal, QThread
from PySide6.QtGui import QColor, QPainter, QPen, QFont, QFontDatabase
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton, QTabWidget, QTableWidget, QTableWidgetItem,
    QComboBox, QHeaderView, QMessageBox)
from presentation import PALETTE, archive_rows
from execution import CampaignRunner, dataset_identity
from campaign import atomic_json
from engine_bridge import load_engine
from archive_reader import read_archive

VERSION = "V17 — DEVELOPMENT, не готовый релиз"


class ResearchWorker(QThread):
    progress = Signal(dict)
    failed = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.runner = CampaignRunner(**settings)

    def run(self):
        try:
            self.runner.run(self.progress.emit)
        except Exception as exc:
            self.failed.emit(str(exc))


class NumericItem(QTableWidgetItem):
    def __init__(self, label, number):
        super().__init__(label)
        self.number = number

    def __lt__(self, other):
        return self.number < other.number if isinstance(other, NumericItem) else super().__lt__(other)


class EquityChart(QWidget):
    def __init__(self):
        super().__init__()
        self.points = []
        self.setMinimumHeight(230)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(PALETTE["panel"]))
        painter.setPen(QColor(PALETTE["muted"]))
        if len(self.points) < 2:
            painter.drawText(self.rect(), Qt.AlignCenter,
                "Лидер текущего запуска V17 ещё не рассчитан\nАрхивные результаты сюда не подставляются")
            return
        left, top, width, height = 65, 25, self.width()-90, self.height()-60
        times, values = zip(*self.points)
        low, high = min(values), max(values)
        spread = max(high-low, 1e-9)
        duration = max(max(times)-min(times), 1)
        painter.drawText(8, top+12, f"{high:,.2f}")
        painter.drawText(8, top+height, f"{low:,.2f}")
        painter.setPen(QPen(QColor(PALETTE["positive"] if values[-1] >= values[0] else PALETTE["negative"]), 2))
        for a, b in zip(self.points, self.points[1:]):
            painter.drawLine(int(left+(a[0]-min(times))/duration*width), int(top+(high-a[1])/spread*height),
                             int(left+(b[0]-min(times))/duration*width), int(top+(high-b[1])/spread*height))


class Inventory(QThread):
    ready = Signal(list)
    failed = Signal(str)

    def run(self):
        try:
            base = Path(r"F:\PUMP Research Lab\data\raw\binance_spot")
            rows = []
            for manifest in sorted(base.glob("*/*/*.manifest.json")):
                try:
                    item = json.loads(manifest.read_text(encoding="utf-8"))
                    raw = manifest.with_name(manifest.name.replace(".manifest.json", ".jsonl"))
                    rows.append((item.get("symbol", manifest.parent.parent.name),
                        item.get("start_utc", ""), item.get("end_utc", ""),
                        item.get("row_count", 0), raw.stat().st_size if raw.exists() else 0,
                        str(raw), "Есть файл; содержимое ещё не проверено" if raw.exists() else "Файл отсутствует"))
                except (OSError, ValueError) as exc:
                    rows.append(("Ошибка", "", "", 0, 0, str(manifest), str(exc)))
            self.ready.emit(rows)
        except Exception as exc:
            self.failed.emit(str(exc))


class ArchiveWorker(QThread):
    ready = Signal(list)
    failed = Signal(str)
    def __init__(self, root, parent=None):
        super().__init__(parent)
        self.root = root
    def run(self):
        try:
            self.ready.emit(read_archive(self.root))
        except Exception as exc:
            self.failed.emit(str(exc))


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PUMP Research Lab · " + VERSION)
        self.resize(1180, 780)
        self.setMinimumSize(850, 600)
        self.workers = []
        self.research_worker = None
        self.last_settings = None
        self.archive_worker = None
        self.archive_page = 0
        self.archive_sort = "net"
        self.archive_descending = True
        self.output_root = (Path(sys.executable).parent if getattr(sys,"frozen",False) else Path(__file__).parent) / "V17-Research"
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 20, 24, 20)
        top = QHBoxLayout()
        title = QLabel("PUMP  /  RESEARCH LAB")
        title.setStyleSheet("font-size:24px;font-weight:600")
        top.addWidget(title)
        top.addStretch()
        top.addWidget(QLabel(VERSION))
        layout.addLayout(top)
        warning = QLabel("Предварительная V17: исследование скачанной базы. Результаты не являются независимым TEST. V16 не изменяется.")
        warning.setWordWrap(True)
        warning.setStyleSheet("color:#F0B90B;padding:10px;background:#191B1F;border-radius:7px")
        layout.addWidget(warning)
        tabs = QTabWidget()
        layout.addWidget(tabs)
        research = QWidget()
        research_layout = QVBoxLayout(research)
        research_layout.addWidget(QLabel("Текущий запуск · V17 · Историческая симуляция, не прогноз"))
        self.status = QLabel("Сначала выберите PUMP-базу во вкладке «Базы данных». Отчёты сохраняются в V17-Research рядом с программой.")
        self.status.setWordWrap(True)
        research_layout.addWidget(self.status)
        controls = QHBoxLayout()
        self.buttons = []
        for label in ("Начать исследование", "Пауза", "Продолжить"):
            button = QPushButton(label)
            button.setEnabled(label != "Пауза")
            self.buttons.append(button)
            controls.addWidget(button)
        self.buttons[0].clicked.connect(self.start_research)
        self.buttons[1].clicked.connect(self.pause_research)
        self.buttons[2].clicked.connect(self.resume_research)
        controls.addStretch()
        research_layout.addLayout(controls)
        self.chart = EquityChart()
        research_layout.addWidget(self.chart)
        filters = QHBoxLayout()
        self.versions = QComboBox()
        self.versions.addItems(["Все версии", "V17", "V16", "V15", "V14", "V13", "V12", "V11"])
        self.threshold = QComboBox()
        self.threshold.addItems(["NET от 20%", "Все результаты"])
        filters.addWidget(QLabel("Архив — отдельно от текущего лидера"))
        filters.addStretch()
        filters.addWidget(self.versions)
        filters.addWidget(self.threshold)
        reload_archive = QPushButton("Обновить архив")
        reload_archive.clicked.connect(self.load_archive)
        filters.addWidget(reload_archive)
        research_layout.addLayout(filters)
        self.archive = QTableWidget(0, 7)
        self.archive.setHorizontalHeaderLabels(["ID", "Версия", "NET", "Сделки", "Окна", "Статус", "Дата"])
        self.archive.setSortingEnabled(False)
        self.archive.horizontalHeader().setSectionsClickable(True)
        self.archive.horizontalHeader().sectionClicked.connect(self.sort_archive)
        self.archive.itemDoubleClicked.connect(self.show_parameters)
        self.archive.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        research_layout.addWidget(self.archive)
        pages = QHBoxLayout()
        previous = QPushButton("← Предыдущие 500")
        following = QPushButton("Следующие 500 →")
        previous.clicked.connect(lambda:self.change_page(-1))
        following.clicked.connect(lambda:self.change_page(1))
        self.page_label = QLabel("Архив ещё не загружен")
        pages.addWidget(previous)
        pages.addWidget(self.page_label)
        pages.addStretch()
        pages.addWidget(following)
        research_layout.addLayout(pages)
        self.archive_records = []
        self.versions.currentTextChanged.connect(self.refresh_archive)
        self.threshold.currentIndexChanged.connect(self.refresh_archive)
        tabs.addTab(research, "Исследование")
        data = QWidget()
        dl = QVBoxLayout(data)
        dl.addWidget(QLabel(r"Исходные базы: F:\PUMP Research Lab\data — доступ только для чтения"))
        actions = QHBoxLayout()
        refresh = QPushButton("Показать имеющиеся базы")
        refresh.clicked.connect(self.scan)
        actions.addWidget(refresh)
        open_folder = QPushButton("Открыть папку баз")
        open_folder.clicked.connect(lambda: os.startfile(r"F:\PUMP Research Lab\data"))
        actions.addWidget(open_folder)
        actions.addStretch()
        dl.addLayout(actions)
        self.datasets = QTableWidget(0, 7)
        self.datasets.setHorizontalHeaderLabels(["Рынок", "Начало UTC", "Конец UTC", "Свечи", "МБ", "Файл", "Состояние"])
        self.datasets.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.datasets.setSortingEnabled(True)
        dl.addWidget(self.datasets)
        tabs.addTab(data, "Базы данных")

    def start_research(self):
        try:
            row = self.datasets.currentRow()
            if row < 0 or self.datasets.item(row,0).text() != "PUMPUSDT":
                raise ValueError("Откройте «Базы данных», нажмите «Показать имеющиеся базы» и выберите строку PUMPUSDT.")
            raw = Path(self.datasets.item(row,5).text())
            base = raw.parent.parent.parent
            paths = [base / symbol / "1m" / raw.name for symbol in ("PUMPUSDT","BTCUSDT","SOLUSDT")]
            if not all(p.exists() for p in paths):
                raise ValueError("Для этого периода отсутствует одинаковый набор PUMP/BTC/SOL. Автоматическая загрузка пока не подключена.")
            if QMessageBox.question(self, "Запуск исследования", "Начать адаптивный расчёт выбранного периода?\nИспользуются два процесса CPU. Исходные базы не изменятся.\nЭто development-поиск, не подтверждение будущей прибыли.") != QMessageBox.Yes:
                return
            engine = load_engine()
            domains = {k:list(v) for k,v in engine.PARAMETER_SPACE.items() if k not in ("max_entries_per_utc_day","min_hours_between_entries")}
            run_id = "v17-" + uuid.uuid4().hex[:12]
            self.output_root.mkdir(parents=True, exist_ok=True)
            settings = dict(directory=str(self.output_root/run_id), paths=list(map(str,paths)), domains=domains,
                context=dict(version="V17", run_id=run_id, dataset_sha256=dataset_identity(paths), engine="V16-frozen", evaluation="development"), workers=2)
            atomic_json(self.output_root/"last_run.json", settings)
            self.launch_research(settings)
        except Exception as exc:
            QMessageBox.warning(self,"Исследование",str(exc))

    def resume_research(self):
        try:
            settings = json.loads((self.output_root/"last_run.json").read_text(encoding="utf-8"))
            if dataset_identity(settings["paths"]) != settings["context"]["dataset_sha256"]:
                raise ValueError("Содержимое базы изменилось; продолжение этого опыта запрещено")
            self.launch_research(settings)
        except Exception as exc:
            QMessageBox.warning(self,"Продолжение",str(exc))

    def launch_research(self, settings):
        if self.research_worker and self.research_worker.isRunning():
            return
        self.chart.points = []
        self.chart.update()
        self.last_settings = settings
        self.research_worker = ResearchWorker(settings, self)
        self.research_worker.progress.connect(self.show_progress)
        self.research_worker.failed.connect(lambda message: QMessageBox.warning(self,"Ошибка расчёта",message))
        self.research_worker.finished.connect(lambda:self.set_running(False))
        self.set_running(True)
        self.research_worker.start()

    def set_running(self, running):
        self.buttons[0].setEnabled(not running)
        self.buttons[1].setEnabled(running)
        self.buttons[2].setEnabled(not running)

    def pause_research(self):
        if self.research_worker:
            self.research_worker.runner.pause_requested.set()
            self.status.setText("Пауза запрошена. Текущие задачи завершатся и сохранятся; новые не запускаются.")

    def show_progress(self, value):
        self.status.setText(f"{value['phase']} · Завершено уникальных вариантов: {value.get('completed',0)} · "
            f"Раунд: {value.get('round','—')} · Размер раунда: {value.get('round_size','—')} · В работе: {value.get('running',0)}")
        best = value.get("best")
        if best and best.get("context") == self.last_settings["context"]:
            self.chart.points = best["equity_curve"]
            self.chart.update()
            self.status.setText(self.status.text()+f"\nЛидер текущего V17: NET {best['net']*100:+.2f}% · Сделок {best['metrics']['fills']} · Капитал {best['final_state']['capital']:.2f} USDT из 1000")

    def refresh_archive(self):
        version = self.versions.currentText()
        records = archive_rows(self.archive_records, None if version == "Все версии" else version,
            None if self.threshold.currentIndex() else .2,column=self.archive_sort,descending=self.archive_descending)
        total = len(records)
        self.archive_page = min(self.archive_page, max(0,(total-1)//500))
        start = self.archive_page*500
        records = records[start:start+500]
        self.page_label.setText(f"Показано {start+1 if total else 0}–{start+len(records)} из {total:,}. Страница — не лимит поиска.")
        self.archive.setSortingEnabled(False)
        self.archive.setRowCount(len(records))
        for row, record in enumerate(records):
            for col, key in enumerate(("id", "version", "net", "trades", "windows", "status", "date")):
                value = record.get(key, "")
                item = NumericItem(f"{value*100:+.2f}%" if key == "net" else str(value), value) if isinstance(value, (int,float)) else QTableWidgetItem(str(value))
                self.archive.setItem(row, col, item)
                if col == 0:
                    item.setData(Qt.UserRole,record.get("parameters",{}))
        self.archive.horizontalHeader().setSortIndicatorShown(True)
        self.archive.horizontalHeader().setSortIndicator(("id","version","net","trades","windows","status","date").index(self.archive_sort),
            Qt.DescendingOrder if self.archive_descending else Qt.AscendingOrder)

    def sort_archive(self, column):
        key = ("id","version","net","trades","windows","status","date")[column]
        self.archive_descending = not self.archive_descending if key == self.archive_sort else True
        self.archive_sort = key
        self.archive_page = 0
        self.refresh_archive()

    def change_page(self, delta):
        self.archive_page = max(0,self.archive_page+delta)
        self.refresh_archive()

    def load_archive(self):
        if self.archive_worker and self.archive_worker.isRunning():
            return
        self.archive_worker = ArchiveWorker(self.output_root,self)
        self.page_label.setText("Читаю архив в отдельном потоке…")
        self.archive_worker.ready.connect(self.set_archive)
        self.archive_worker.failed.connect(lambda message:QMessageBox.warning(self,"Архив",message))
        self.archive_worker.start()

    def set_archive(self, records):
        self.archive_records = records
        self.refresh_archive()

    def show_parameters(self, item):
        first = self.archive.item(item.row(),0)
        message = QMessageBox(self)
        message.setWindowTitle(first.text())
        message.setText("Параметры сохранённого варианта. Архив не заменяет текущего лидера.")
        message.setDetailedText(json.dumps(first.data(Qt.UserRole),ensure_ascii=False,indent=2))
        message.exec()

    def scan(self):
        if any(worker.isRunning() for worker in self.workers):
            return
        worker = Inventory(self)
        worker.ready.connect(self.show_inventory)
        worker.failed.connect(lambda message: QMessageBox.warning(self, "Каталог баз", message))
        self.workers = [worker]
        worker.start()

    def show_inventory(self, records):
        self.datasets.setSortingEnabled(False)
        self.datasets.setRowCount(len(records))
        for row, record in enumerate(records):
            for column, value in enumerate(record):
                label = f"{value/1048576:.1f}" if column == 4 else str(value)
                self.datasets.setItem(row,column,NumericItem(label,value) if column in (3,4) else QTableWidgetItem(label))
        self.datasets.setSortingEnabled(True)

    def closeEvent(self, event):
        if self.research_worker and self.research_worker.isRunning():
            self.pause_research()
            event.ignore()
        elif any(worker.isRunning() for worker in self.workers) or (self.archive_worker and self.archive_worker.isRunning()):
            event.ignore()
            self.status.setText("Дождитесь завершения чтения каталога баз")
        else:
            event.accept()


def configure_app(app):
    app.setStyle("Fusion")
    font_path = Path(os.environ.get("WINDIR", r"C:\Windows"))/"Fonts"/"segoeui.ttf"
    if font_path.exists():
        QFontDatabase.addApplicationFont(str(font_path))
    app.setFont(QFont("Segoe UI", 10))
    app.setStyleSheet('''
        QWidget {background:#101113;color:#ECEDEF;font-family:Segoe UI;font-size:13px;}
        QPushButton,QComboBox {background:#25282D;border:1px solid #363A40;border-radius:6px;padding:8px 14px;}
        QPushButton:hover {border-color:#F0B90B;} QPushButton:disabled {color:#666A70;}
        QTabBar::tab {padding:10px 18px;} QTabBar::tab:selected {color:#F0B90B;border-bottom:2px solid #F0B90B;}
        QHeaderView::section {background:#25282D;color:#A5ABB5;padding:8px;border:0;}
        QTableWidget {background:#191B1F;gridline-color:#303238;selection-background-color:#514728;}
    ''')


def main():
    app = QApplication(sys.argv)
    configure_app(app)
    window = Window()
    window.show()
    return app.exec()


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    if len(sys.argv) == 3 and sys.argv[1] == "--self-test":
        from packaged_smoke import run
        raise SystemExit(run(sys.argv[2]))
    raise SystemExit(main())
