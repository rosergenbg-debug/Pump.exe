"""Explicit offline packaged-app check. Never touches the user's market data."""
from dataclasses import replace
from pathlib import Path
import json
import os
import traceback


def run(directory):
    root = Path(directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    try:
        from engine_bridge import load_engine
        from execution import CampaignRunner, dataset_identity
        load_engine()
        from pump_research_lab.demo import demo_candles
        paths = []
        for symbol in ("PUMPUSDT","BTCUSDT","SOLUSDT"):
            path = root/(symbol+".jsonl")
            with path.open("w",encoding="utf-8") as handle:
                for candle in demo_candles():
                    handle.write(json.dumps(replace(candle,symbol=symbol).to_dict())+"\n")
            paths.append(path)
        context = dict(version="V17",run_id="packaged-smoke",dataset_sha256=dataset_identity(paths),
                       engine="V16-frozen",evaluation="synthetic-test-only")
        runner = CampaignRunner(root/"experiment",paths,{"target_net":[.025]},context,workers=2)
        messages = []
        runner.run(messages.append)
        runner.run(messages.append)
        assert messages[-1]["completed"] == 1
        assert abs(messages[-1]["best"]["net"]-.025) < 1e-10
        os.environ["QT_QPA_PLATFORM"] = "offscreen"
        from PySide6.QtWidgets import QApplication
        from desktop import Window, configure_app
        app = QApplication.instance() or QApplication([])
        configure_app(app)
        window = Window()
        window.show()
        app.processEvents()
        window.grab().save(str(root/"window.png"))
        window.close()
        result = dict(status="PASS", unique_completed=1, repeat_did_not_recalculate=True,
                      warning="Synthetic execution test, not trading profitability evidence")
    except Exception:
        result = dict(status="FAIL",error=traceback.format_exc())
    (root/"smoke.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    return 0 if result["status"] == "PASS" else 1
