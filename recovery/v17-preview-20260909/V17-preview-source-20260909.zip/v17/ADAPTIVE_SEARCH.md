# V17: adaptive research, not exhaustive enumeration

Owner clarification 2026-09-09 supersedes the earlier exhaustive-space design.
There is no pending question about whether adaptive search is authorized.

## Algorithm

1. Freeze engine version, dataset hashes, chronological development folds,
   execution costs, parameter domains and random seeds before the campaign.
2. Use multivariate TPE to propose conditional parameter combinations using
   accumulated completed and pruned trials. Start with broad exploration across
   entry families; continue explicit independent exploration to reduce collapse.
3. Deduplicate the effective configuration, not inactive parameters. Reserve the
   candidate transactionally before dispatching a worker. Retain failures and
   early-stopped trials; do not pretend they were full-history evaluations.
4. Replay chronologically with causal signals and unchanged execution semantics.
   At fixed development checkpoints compare candidates on the same intervals,
   starting capital, fees, data and fidelity. Never compare a one-month NET with
   another candidate's one-year NET to decide pruning.
5. Main completed objective is full-development NET after costs. A negative NET
   is a penalty, a positive NET a reward; improvement over a parent's NET is a
   diagnostic for that search direction. Do not subtract commissions twice.
   Risk, uncertainty and concentration are reported separately; do not silently
   replace the owner's maximum-NET objective with an arbitrary penalty formula.
6. Patient early stopping: only consider pruning after a warm-up and enough
   comparable completed references, and after repeated weak checkpoints. One
   worsening neighbour is not evidence that every descendant is bad. Suspend a
   direction, retain its evidence and permit cross-parameter or broad exploration
   to revisit it. Pruning is a heuristic, never a proof of an invalid region.
7. Completed candidates alone can become the live full-period leader. Partial
   and pruned candidates have their own views. Version/run/data/evaluation identity
   must match the active run. Display threshold 20% never controls sampling.
8. Automatic campaign stop is separate from trial pruning. Use declared stable
   improvement tolerance and patience across exploration rounds, only after all
   active families have received new exploratory checks and independent restarts
   fail to improve. Save the exact stop-policy values and evidence in the report.
   This is heuristic convergence, not proof of the global maximum. Trial-count or
   runtime ceilings must not silently replace convergence.
9. Freeze one selected candidate before final assessment. TEST and holdout never
   provide rewards, pruning decisions or stopping signals. Previously inspected
   history remains exploratory; future unseen data is needed for fresh evidence.
10. Persist sampler RNG/state, study, reservations, family coverage, stop state,
    results and reasons. Drain or checkpoint in-flight tasks on pause/stop.

## UI counters

Theoretical combinations; unique proposed; fully evaluated; early stopped;
invalid configurations; errors; pending/running; active/suspended directions;
best improvement; current round and batch size; reason for automatic stop.
Theoretical space is not the completion denominator for adaptive research.
Never display 100% of the theoretical space when only convergence was reached.

## References and scope

- https://optuna.readthedocs.io/en/stable/tutorial/10_key_features/003_efficient_optimization_algorithms.html
- https://optuna.readthedocs.io/en/stable/reference/generated/optuna.pruners.MedianPruner.html
- https://arxiv.org/abs/1603.06560

Optuna separates parameter sampling from trial pruning. Hyperband provides a
resource-allocation/early-stopping approach; it does not prove that a trading
strategy losing in one regime will also lose in every subsequent regime.
TPE is adaptive parameter optimization, not a claim of a trained neural trading
policy or implemented offline reinforcement learning. Protected baseline X and
V16 fixtures remain unchanged. This document specifies intended integration;
it is not evidence that the full V17 application is already implemented.
