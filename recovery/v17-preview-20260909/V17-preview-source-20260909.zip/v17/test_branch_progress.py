import unittest
from branch_progress import BranchProgress, behavior_fingerprint


class BranchTests(unittest.TestCase):
    def test_same_profit_different_trades_not_duplicate(self):
        self.assertNotEqual(behavior_fingerprint({}, [{"entry": 1}], [], {}),
                            behavior_fingerprint({}, [{"entry": 2}], [], {}))

    def test_repeated_plateau_rests_not_forever(self):
        branch = BranchProgress(patience=2)
        update = lambda values: branch.finish_round(values, comparable_complete=True, directions_covered=True)
        self.assertEqual(update([("a", 1.0)]), "ACTIVE")
        self.assertEqual(update([("a", 1.0)]), "ACTIVE")
        self.assertEqual(update([("a", 1.0)]), "RESTING")
        branch.reopen("new_joint_parameter_direction")
        self.assertEqual(update([("b", 1.2)]), "ACTIVE")

    def test_hundred_percent_is_not_profit_cap(self):
        branch = BranchProgress()
        for n in range(5):
            self.assertEqual(branch.finish_round([(str(n), 1.0+n)],
                comparable_complete=True, directions_covered=True), "ACTIVE")

    def test_incomplete_evidence_does_not_kill_branch(self):
        branch = BranchProgress()
        for _ in range(10):
            branch.finish_round([("loss", -.5)], comparable_complete=False, directions_covered=True)
        self.assertEqual(branch.stagnant_rounds, 0)

    def test_tiny_improvement_retained_but_not_infinite_focus(self):
        branch = BranchProgress(patience=1)
        branch.finish_round([("a", 1)], comparable_complete=True, directions_covered=True)
        branch.finish_round([("b", 1.00001)], comparable_complete=True, directions_covered=True)
        self.assertEqual(branch.best_net, 1.00001)
        self.assertEqual(branch.state, "RESTING")
