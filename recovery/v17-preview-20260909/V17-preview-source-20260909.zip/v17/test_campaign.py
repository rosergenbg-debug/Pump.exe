import tempfile
import unittest
import warnings
import optuna
from campaign import Campaign


class CampaignTests(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore", optuna.exceptions.ExperimentalWarning)
        optuna.logging.set_verbosity(optuna.logging.ERROR)
        self.tmp = tempfile.TemporaryDirectory()
        self.campaigns = []
        self.context = dict(run_id="fixture", version="V17", dataset_sha256="fixture", engine="V16", evaluation="development")

    def tearDown(self):
        for campaign in self.campaigns:
            campaign.close()
        self.tmp.cleanup()

    def test_archive_and_sampler_receive_same_result(self):
        campaign = Campaign(self.tmp.name, {"x": [1,2,3]}, self.context)
        self.campaigns.append(campaign)
        campaign.round_size = 1
        item = campaign.propose_round()[0]
        result = dict(context=self.context, parameters=item["parameters"], net=.25,
                      trades=[], equity_curve=[[0,1000],[1,1250]], final_state={"equity":1250})
        campaign.record(item, result)
        self.assertEqual(campaign.best(), result)
        campaign.record(item, result)
        self.assertEqual(len(campaign.state["results"]), 1)
        campaign.finish_round()
        self.assertNotEqual(campaign.state["phase"], "COMPLETED")

    def test_pending_round_is_resumed_not_replaced(self):
        campaign = Campaign(self.tmp.name, {"x": [1,2,3]}, self.context)
        self.campaigns.append(campaign)
        campaign.round_size = 1
        first = campaign.propose_round()
        self.assertEqual(campaign.propose_round(), first)
        with self.assertRaises(ValueError):
            campaign.finish_round()


if __name__ == "__main__":
    unittest.main()
