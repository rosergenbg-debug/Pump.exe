import unittest
import warnings
import optuna
from adaptive_search import AdaptiveSearch, effective_parameters


class AdaptiveTests(unittest.TestCase):
    def test_bound_pairs_cannot_contradict(self):
        self.assertEqual(effective_parameters(dict(min_rsi=90,max_rsi=10)),dict(min_rsi=10,max_rsi=90))
    def setUp(self):
        optuna.logging.set_verbosity(optuna.logging.ERROR)
        warnings.simplefilter("ignore", optuna.exceptions.ExperimentalWarning)

    def test_duplicate_is_not_replayed(self):
        search = AdaptiveSearch({"x": [1]}, {"run_id": "unique"})
        trial, parameters = search.ask()
        search.finish(trial, 0.1)
        self.assertIsNone(search.ask(attempts=2))
        self.assertEqual(sum(t.state == optuna.trial.TrialState.COMPLETE for t in search.study.trials), 1)

    def test_first_loss_does_not_prune_branch(self):
        search = AdaptiveSearch({"x": [1, 2]}, {"run_id": "warmup"})
        trial, _ = search.ask()
        self.assertFalse(search.report(trial, 0, -0.5))

    def test_pruned_is_not_completed(self):
        search = AdaptiveSearch({"x": [1, 2]}, {"run_id": "pruned"})
        trial, _ = search.ask()
        search.report(trial, 0, -0.3)
        search.prune(trial, "test-only evidence")
        self.assertEqual(search.study.trials[0].state, optuna.trial.TrialState.PRUNED)


if __name__ == "__main__":
    unittest.main()
