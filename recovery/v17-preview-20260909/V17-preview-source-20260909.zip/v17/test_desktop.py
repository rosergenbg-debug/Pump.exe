import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import unittest
from PySide6.QtWidgets import QApplication
from desktop import Window, NumericItem


class DesktopTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_window_has_empty_current_leader_and_no_fake_search(self):
        window = Window()
        self.assertEqual(window.chart.points, [])
        self.assertEqual(window.archive.rowCount(), 0)
        self.assertIn("DEVELOPMENT", window.windowTitle())
        window.close()

    def test_native_numeric_sort(self):
        self.assertLess(NumericItem("2", 2), NumericItem("10", 10))

    def test_archive_filter_does_not_change_live_chart(self):
        window = Window()
        window.archive_records = [dict(id="old", version="V16", net=2, trades=3),
                                  dict(id="new", version="V17", net=.3, trades=10)]
        window.versions.setCurrentText("V17")
        self.assertEqual(window.archive.rowCount(), 1)
        self.assertEqual(window.archive.item(0, 0).text(), "new")
        self.assertEqual(window.chart.points, [])
        window.close()
